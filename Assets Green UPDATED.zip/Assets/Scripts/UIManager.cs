using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TMPro;
using UnityEngine.UI;

[Serializable()]
public struct UIManagerParameters
{
//he struct (structure) is like a class in C# that is used to store data. 
//However, unlike classes, a struct is a value type. Suppose we want to store the name and age of a person. 
//We can create two variables: name and age and store value.

//Here, the parameteres will be declared 
    [Header("Answer Options")]
    [SerializeField]
    float margins;
    public float Margins {get { return margins; }}

    [Header("Resolution Screens")]   //the three resolution screens need different colors
    [SerializeField]
    Color correct;   //GREEN
    public Color Correct {get { return correct; }}

    [SerializeField]
    Color incorrect; //RED
    public Color Incorrect {get { return incorrect; }}

    [SerializeField]
    Color final;  //BLUE
    public Color Final {get { return final; }}
}


[Serializable()]
public struct UIElements      
{
   //All the UI elements are declared here
   //Getters give public access to private data, and they may also make a small modification of the returned result. 
    [SerializeField]
    RectTransform answerContentArea;   //The answer text will appear here
    public RectTransform AnswerContentArea { get { return answerContentArea; }}

    [SerializeField]
    TextMeshProUGUI questionInfoText;  //for the questions text
    public TextMeshProUGUI QuestionInfoText { get { return questionInfoText; }}

    [SerializeField]
    TextMeshProUGUI scoreText;  //the score text
    public TextMeshProUGUI ScoreText { get { return scoreText ; }}

    [Space]   //this will give space, and show the elements with spaces in between in the inspecter. 
    //the only purpose is to have some kind of organization when we actually define it because there are too many Elements
    //it can look messy

    [SerializeField]
    Animator resolutionScreenAnimator;    //to display the animation saying CORRECT! +10
    public Animator ResolutionScreenAnimator { get { return resolutionScreenAnimator; }}


    [SerializeField]
    Image resolutionScreenBack;   //THE BACKGROUND 
    public Image ResolutionScreenBack { get { return resolutionScreenBack; }}

    [SerializeField]
    TextMeshProUGUI resolutionScreenInfoText;  //text for the animation
    public TextMeshProUGUI ResolutionScreenInfoText { get { return resolutionScreenInfoText ; }}

    [SerializeField]
    TextMeshProUGUI resolutionScoreText;   //the score for correct/incorrect/final 
    public TextMeshProUGUI ResolutionScoreText { get { return resolutionScoreText ; }}


    [Space]   //again for organization and readability. 

     [SerializeField]
    TextMeshProUGUI highScoreText;
    public TextMeshProUGUI HighScoreText { get { return highScoreText ; }}

    [SerializeField]
    CanvasGroup mainCanvas;   //this canvas has the question text, answer text and the scrollbar and options
    public CanvasGroup MainCanvas { get { return mainCanvas; }}

    [SerializeField]
    RectTransform finishUIElements;   //this will show highscore, replay, exit 
    public RectTransform FinishUIElements { get { return finishUIElements ; }}


}


public class UIManager : MonoBehaviour
{
    public enum ResolutionScreenType { Correct, Incorrect, Finish}   //Resolution Screen Types 

    [Header("References")]
    [SerializeField]
    GameEvents events;    //reference to teh script

    [Header("UI Elements/Prefabs")]
    [SerializeField]
    AnswerData answerPrefab;   //reference to the answer prefab

    [SerializeField]
    UIElements uIElements;   //reference 

    [Space]

     [SerializeField]
    UIManagerParameters parameters;    //reference 
      
    List<AnswerData> currentAnswer = new List<AnswerData>();
    private int resolutionStateParamHash =0;    //use this to store the animator paramter hash
    //more effective than string

    private IEnumerator IEDisplayTimedRes;

    void OnEnable()
    {
      events.UpdateQuestionUI += UpdateQuestionUI;
      events.DisplayResolutionScreen += DisplayRes;
      events.ScoreUpdated += UpdateScoreUI;
    }

    void OnDisable()
    {
      events.UpdateQuestionUI -= UpdateQuestionUI;
      events.DisplayResolutionScreen -= DisplayRes;
      events.ScoreUpdated -= UpdateScoreUI;
    }

    void Start()
    {
        resolutionStateParamHash = Animator.StringToHash("ScreenState");
    }

    void UpdateQuestionUI(QuizQuestions questions)
    {
      uIElements.QuestionInfoText.text = questions.Info;
      CreateAnswers(questions);
    }
    
    void DisplayRes(ResolutionScreenType type, int score)  //to DisplayResolutionscreen
    {
       UpdateResUI(type, score);
       uIElements.ResolutionScreenAnimator.SetInteger(resolutionStateParamHash, 2);   //as defined earlier for the correct incorrect and finish screens 
       uIElements.MainCanvas.blocksRaycasts = false;   //the screen will not take any input here

       if(type != ResolutionScreenType.Finish)
       {
          if(IEDisplayTimedRes != null)
          {
                StopCoroutine(IEDisplayTimedRes);
          }

          IEDisplayTimedRes = DisplayTimedResolution();
          StartCoroutine(IEDisplayTimedRes);

       }

    }

    IEnumerator DisplayTimedResolution()   //just to show correct/incorrect final
    {
       yield return new WaitForSeconds(GameUtility.ResolutionDelayTime);
       uIElements.ResolutionScreenAnimator.SetInteger(resolutionStateParamHash, 1);  //paramhash 1 will hide the screen 
       uIElements.MainCanvas.blocksRaycasts = true;
    }


    void UpdateResUI(ResolutionScreenType type, int score)  //Updating the screens for every correct/incorrect or final screen
    {
      //Getting the highscore from other game utility using PlayerPrefs
      var highscore = PlayerPrefs.GetInt(GameUtility.SavePrefKey);  //the score will be stored here
    
      switch (type)
       {
              case ResolutionScreenType.Correct:
              uIElements.ResolutionScreenBack.color = parameters.Correct;   //reference to the background color 
              uIElements.ResolutionScreenInfoText.text = "Correct!";  //reference to teh score text
              uIElements.ResolutionScoreText.text = "+" + score;   //to display the score 
              break;


              //the same applies to the case incorrect 
              case ResolutionScreenType.Incorrect:   // 
              uIElements.ResolutionScreenBack.color = parameters.Incorrect;
              uIElements.ResolutionScreenInfoText.text = "Incorrect!";
              uIElements.ResolutionScoreText.text = "-" + score;
              break;

              //and Finish - same reference 
              case ResolutionScreenType.Finish:// 
               uIElements.ResolutionScreenBack.color = parameters.Final;
              uIElements.ResolutionScreenInfoText.text = "Final Score : ";
              

              StartCoroutine(CalculateScore());
              uIElements.FinishUIElements.gameObject.SetActive(true);   //All game finish elements will be displayed like total score
              uIElements.HighScoreText.gameObject.SetActive(true); //the HighScoreText will indicate the final score obtained. 
              uIElements.HighScoreText.text = ((highscore > events.StartHighScore) ? "<color=yellow>new</color>" : string.Empty) + "High SCore: " + highscore;
              // rich text tags 
              //You can use rich text tags to change the appearance and layout of teh text. 
              //These tags work like HTML or XML tags, but have easier syntax
              break;
       }
    }

    //To Store the score and calculate it
    IEnumerator CalculateScore()
    {
        int scoreValue = 0;
        while(scoreValue < events.CurrentFinalScore)   //the CurrentFinalScore stores the current Score
        {
          scoreValue++;
          uIElements.ResolutionScoreText.text = scoreValue.ToString();   //it will return the score
          yield return null;
        }
    }




    void CreateAnswers(QuizQuestions questions)    //Will add new answers 
    {
      EraseAnswers();  //Erase all previous answers

      //Create new answers
      float offset =0 - parameters.Margins;

      for (int i=0; i< questions.Answers.Length; i++)
      {
            AnswerData newAnswer = (AnswerData)Instantiate(answerPrefab, uIElements.AnswerContentArea);
            newAnswer.UpdateData(questions.Answers[i].Info, i);

            newAnswer.Rect.anchoredPosition = new Vector2(0, offset);

            offset -= (newAnswer.Rect.sizeDelta.y + parameters.Margins);
            uIElements.AnswerContentArea.sizeDelta = new Vector2(uIElements.AnswerContentArea.sizeDelta.x, offset * -1);

            currentAnswer.Add(newAnswer);

      }

    }

    void EraseAnswers()    //to erase the previous answers
    {
        foreach (var answer in currentAnswer)
        { 
            Destroy(answer.gameObject);  //destroy all the previously stores answers 
        }

        currentAnswer.Clear(); // clear the list for next items to be stored 
    }

    void UpdateScoreUI()
    {
        uIElements.ScoreText.text = "score" + events.CurrentFinalScore;
    }
}
