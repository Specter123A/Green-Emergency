using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    QuizQuestions[] questions = null;     //all questions will be stored here
    public QuizQuestions[] Questions {get { return questions; }}

    private List<int> FinishedQuestions = new List<int>();    //all questions that have been asked
    private int currentQuestion = 0;
    private int score;

    [SerializeField]
    GameEvents events = null;

    [SerializeField]  Animator timerAnim = null;
     [SerializeField]  TextMeshProUGUI timerText = null;

    private List<AnswerData> pickedAnswers = new List<AnswerData>();   //the answer list
    private IEnumerator  IEWaitTillNextRound = null;
    private IEnumerator  startTimer = null;   //for the Timer IE
    private bool isFinished  { get { return (FinishedQuestions.Count < Questions.Length) ? false : true; }}  //this getter will check and return if the game is finished
    private int timerParamHash =0;   //for the timer state
    

    void OnEnable()    //The answer UI and content area needs to be updated
    {
       events.UpdateAnswerUI +=UpdateAnswers;
    }

    void OnDisable()
    {
         events.UpdateAnswerUI -=UpdateAnswers;     //and then removed for the next onw 
    }

    void Awake()
    {
        events.CurrentFinalScore = 0;  //calling in Awake becasue it needs to be reset before the start 
    }

    void Start()    //load question, check score 
    {
        
       
    events.StartHighScore = PlayerPrefs.GetInt(GameUtility.SavePrefKey);
    LoadQuestions();  
        
        timerParamHash = Animator.StringToHash("TimerState");


       var seed = UnityEngine.Random.Range(int.MinValue, int.MaxValue);    //This is for random question generation 
    //A number used to calculate a starting value for the pseudo-random number sequence. 
    UnityEngine.Random.InitState(seed);
      
    Display();
    }

    public void UpdateAnswers(AnswerData newAnswer)   //this method updates the answer area
    {
        if (Questions[currentQuestion].GetAnswerType == QuizQuestions.AnswerType.Single)
        {
        foreach( var answer in pickedAnswers )
        {
           if (answer != newAnswer)
           {
                  answer.Reset();
           }
            pickedAnswers.Clear();
            pickedAnswers.Add(newAnswer);
        }
    }

         else 
         {    //if the answer is already picked, then the second answer selected will be removed 
              bool alreadyPicked = pickedAnswers.Exists(x => x== newAnswer);
              if(alreadyPicked)
              {
                    pickedAnswers.Remove(newAnswer);
              }

              else 
              {
                    pickedAnswers.Add(newAnswer);
              }
         }
    }


    private void EraseAnswers()   //we need to erase it so that we can store new answers later for the enxt question
    {
      pickedAnswers = new List<AnswerData>();
    }


    void Display()
    {
      EraseAnswers();
      var question = GetRandomQuestion();

      if(events.UpdateQuestionUI != null)
      {
            events.UpdateQuestionUI(question);
      }

      else 
      {
            Debug.Log(" Delegate is null. Check GameManager.Display() method");   //just to have reference and an idea regarding what's wrong'
      }


      if(question.UseTimer)
      {
            UpdateTimer(question.UseTimer);
      }

    }

    public void Accept()
    {
        UpdateTimer(false);
        bool isCorrect = CheckAnswers();
        FinishedQuestions.Add(currentQuestion);

        

        UpdateScore((isCorrect)  ? Questions[currentQuestion].AddScore  : -Questions[currentQuestion].AddScore);
        //Here, I am checking if the answer is correct. 
        //If the answer is correct, the score will be added by +10
        //But if the answer is not correct, the score will be -10.  //this is done by sending a negative value of AddScore  

        if(isFinished)
        {
            SetHighScoreCheck();
        }
        
        var type = (isFinished) ? UIManager.ResolutionScreenType .Finish : (isCorrect)  ? UIManager.ResolutionScreenType.Correct : UIManager.ResolutionScreenType.Incorrect;
        //Here it will check the the answer types and based on that the resolution screen will be displayed. 
        //if the answers are correct, ResolutionScreenType.Correct, and if false, ResolutionScreenType.Incorrect 

        //Check if the resolution screen is !null
        if(events.DisplayResolutionScreen != null)
        {
            events.DisplayResolutionScreen(type, Questions[currentQuestion].AddScore);
        }
        
        if(IEWaitTillNextRound !=null)
        {
            StopCoroutine(IEWaitTillNextRound); //If it is not not null, then the coroutine should stop
        }

        IEWaitTillNextRound = WaitTillNextRound();  //else we will start it
        StartCoroutine(IEWaitTillNextRound);
    }



    void UpdateTimer(bool state )   //to update the timer // a set time to answer the question
    {
        switch(state)
        {
            case true:
            startTimer = StartTimer();
            StartCoroutine(startTimer);
            break;

            case false:
            if(startTimer !=null)
            {
                StopCoroutine(startTimer);

            }
            break;
        }
    }

    IEnumerator StartTimer()   //to start the timer 
    {
        var totalTime = Questions[currentQuestion].Timer;
        var timeLeft = totalTime;

        while(timeLeft <0)
        {
            timeLeft --;
            timerText.text = timeLeft.ToString();
            yield return new WaitForSeconds(1.0f);
        }
    }

    IEnumerator WaitTillNextRound()
    {
        // here we need to determine how much wait time is needed before next question
        //Related to the Script Game Utilities 
        yield return new WaitForSeconds(GameUtility.ResolutionDelayTime);
        Display();
    }

    bool CheckAnswers()     //compare answers //the selected and correct 
    {
       if(!CompareAnswers())
       {
              return false;
       }

       return true;

       //update score
    }


    bool CompareAnswers()
    {
      if(pickedAnswers.Count >0)
      {
         List<int> c= Questions[currentQuestion].GetCorrectAnswers();  //c is for correct answers
         List<int> p = pickedAnswers.Select(x => x.AnswerIndex).ToList();   //p is for picked answers
         //the two lists will be compared to see how many of the picked amswers were correct

         var f=c.Except(p).ToList();
         //will remove all elements from the list except picked answers

         var s =p.Except(c).ToList();
         //will remove all elements from the list except correct answers

         return !f.Any() && !s.Any();   //will return if there are any items in the list

      }

      return false;
    }



    QuizQuestions GetRandomQuestion()    //to get random questions based on the index. We will simply shuffle it. 
    {
       var randomIndex = GetRandomQuestionIndex();
       currentQuestion = randomIndex;

       return Questions[currentQuestion];
    }

    int GetRandomQuestionIndex()    //this is the index for the questions 
    {
        var random = 0;
        if( FinishedQuestions.Count < Questions.Length)
        {
            do 
            {
                random = UnityEngine.Random.Range(0, Questions.Length);
            }

            while (FinishedQuestions.Contains(random) || random == currentQuestion);

        }

        return random;
    }


    void LoadQuestions()    //loading questions onto the UI
    {
        Object[] obj = Resources.LoadAll("Questions", typeof(QuizQuestions));
        questions = new QuizQuestions[obj.Length];

        for (int i =0; i< obj.Length; i++)
        {
            questions[i] = (QuizQuestions)obj[i];
        }
    }

      //Update score if correct or incorrect
    private void UpdateScore(int add)
    {
       events.CurrentFinalScore += add;
       if(events.ScoreUpdated  != null)    //check if the delegate is not equal to null 
       {
              events.ScoreUpdated();  //call the delegate from events class if not null
       }
    }

    //to store the Highscore 
    private void SetHighScoreCheck()
    {
      var highscore = PlayerPrefs.GetInt(GameUtility.SavePrefKey);
      if(highscore <events.CurrentFinalScore)    //here we will check if the CurrentFinalScore is greater than the highscore we last saved in PlayerPrefs
      //if yes, the highscore will be updated 
      {
            PlayerPrefs.SetInt(GameUtility.SavePrefKey, events.CurrentFinalScore);
      }
    }


    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
