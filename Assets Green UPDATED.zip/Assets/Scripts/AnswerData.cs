using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class AnswerData : MonoBehaviour
{

//the asnwer data relates to teh answer content area 
//the UI elements include the scroll bar to allow the player to see the answers in case there are 5 options instead to 2
    [Header ("UI Elements")]

    [SerializeField]
    TextMeshProUGUI infoTextObject;

    //different images for toggle have been used
    //initially it is white circle
    //selecting it makes it green
    //select again, and you'll see it turn red, indicating that it is uncheckToggle

    [SerializeField]
    Image toggle;

    [Header("Textures")]
    [SerializeField]
    Sprite uncheckToggle;

    [SerializeField]
    Sprite checkToggle;

    [Header("References")]
    [SerializeField]
    GameEvents events;

    private RectTransform rect;
    public RectTransform Rect
    {
        get 
        {
            if (rect ==null)
            {
                rect = GetComponent<RectTransform> () ?? gameObject.AddComponent<RectTransform>();
            }
            
            return rect;
            }
    }

    private int answerIndex =-1;
    public int AnswerIndex {get { return answerIndex; }}

    private bool Checked = false; 

    public void UpdateData(string info, int index)
    {
      infoTextObject.text = info;
      answerIndex = index;
    }

    public void Reset()
    {
        Checked = false;
        UpdateUI();
    }

    public void SwitchState()
    {
        Checked = !Checked;
        UpdateUI();

        if (events.UpdateAnswerUI !=null)
        {
            events.UpdateAnswerUI(this);
        }
    }

    void UpdateUI()   //this updates the UI on every click 
    {
        toggle.sprite = (Checked) ? checkToggle : uncheckToggle;
    }
}
