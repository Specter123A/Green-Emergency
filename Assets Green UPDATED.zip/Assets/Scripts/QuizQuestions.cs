using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public struct Answer
{

//The struct (structure) is like a class in C# that is used to store data. However, unlike classes, a struct is a value type. 
//Suppose we want to store the name and age of a person. We can create two variables: name and age and store value.

//Here, this struct stores the answers
    [SerializeField] private string info;
    public string Info { get { return info; }}

    [SerializeField] private bool isCorrect;
    public bool IsCorrect { get { return isCorrect; }}
}

[CreateAssetMenu(fileName = "Questions", menuName = "New Question")]

public class QuizQuestions : ScriptableObject
{

//ScriptableObject is a serializable Unity class that allows you to store large quantities of shared data independent from script instances. 
//Using ScriptableObjects makes it easier to manage changes and debugging.

//this class will deal with the Questions
//all quiz questions will be created in the editor
   public enum AnswerType { Multi, Single}

    [SerializeField] 
    private string info=string.Empty;
    public string Info{ get { return info; }}


    [SerializeField] 
    Answer [] answers = null;
    public Answer[] Answers { get { return answers; }}

// by serializing these fields, we'll be able to manipulate and edit it in the inspector window. 
//the SerializeField doesnt craete public objects, but here the variables are made public using getters

// Generally, it getter and setters are made public to provide acess to other classes.

    //parameters

    [SerializeField]  
    private bool useTimer = false;
    public bool UseTimer { get { return useTimer; }}

    [SerializeField]
    private int timer =0;
    public int Timer { get { return timer; }}

    [SerializeField]
    private AnswerType answerType = AnswerType.Multi;
    public AnswerType GetAnswerType  { get { return answerType; }}

    [SerializeField]
    private int addScore= 10;
    public int AddScore { get { return addScore;}}

    public List<int> GetCorrectAnswers()
    {
        List <int> CorrectAnswers = new List<int>();
        for (int i=0; i<Answers.Length; i++)
        {   
             if(Answers[i].IsCorrect)
                {
                    CorrectAnswers.Add(i);
               }
        }
       return CorrectAnswers;
    }
   
}


