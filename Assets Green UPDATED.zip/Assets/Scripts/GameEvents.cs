using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//Here are all the delegates that will be called 
//Delegates allow methods to be passed as parameters. 
//Delegates can be used to define callback methods. 
//They can be chained together; for example, multiple methods can be called on a single event. 
//Methods don't have to match the delegate type exactly.

[CreateAssetMenu(fileName = "GameEvents", menuName = "Quiz")]
public class GameEvents : ScriptableObject
{
    public delegate void UpdateQuestionUICallBack (QuizQuestions question);
    public UpdateQuestionUICallBack UpdateQuestionUI;
    //the questions will be displayed next

    public delegate void UpdateAnswerUICallBack (AnswerData answer);
    public UpdateAnswerUICallBack UpdateAnswerUI;
    //answer options for each question will be updated


    public delegate void DisplayResolutionScreenCallBack (UIManager.ResolutionScreenType type, int score);
    public DisplayResolutionScreenCallBack DisplayResolutionScreen;    
    //this will be called everytime we display the ResolutionScreen, that is Correct +10, or Incorrect -10

    public delegate void ScoreUpdatedCallBack();
    public ScoreUpdatedCallBack ScoreUpdated;
    //score will also be updated

   [HideInInspector]
    public int CurrentFinalScore;
    //will store the score at any point in the game 
    //for example at Q7, if you want to check, it will the be CurrentFinalScore

    [HideInInspector]
    public int StartHighScore;
    // the score from the game 
    //the current final high score and start high score will be compared to update the highscores
}
